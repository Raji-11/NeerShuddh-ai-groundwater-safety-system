import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: '50mb' }));

  // Mock Database
  let submissions: any[] = [
    {
      id: "1",
      type: "volunteer",
      status: "pending",
      color: "yellow",
      location: { lat: 28.6139, lng: 77.2090, district: "New Delhi", state: "Delhi" },
      timestamp: new Date(Date.now() - 86400000).toISOString(),
      imageUrl: "https://picsum.photos/seed/water1/400/300"
    },
    {
      id: "2",
      type: "asha",
      status: "completed",
      risk: "Dangerous",
      location: { lat: 26.8467, lng: 80.9462, district: "Lucknow", state: "Uttar Pradesh" },
      chemicals: {
        fluoride: 2.5,
        arsenic: 0.06,
        nitrate: 55,
        ph: 8.2,
        tds: 1200,
        iron: 0.8,
        rainfall: 800,
        depth: 45
      },
      timestamp: new Date(Date.now() - 172800000).toISOString(),
      analysis: {
        prediction: "Dangerous",
        confidence: 0.92,
        failedChemicals: ["Fluoride", "Arsenic", "Nitrate"],
        risks: ["Fluorosis", "Cancer", "Kidney Damage"],
        recommendation: "DO NOT DRINK WATER"
      }
    }
  ];

  // API Routes
  app.get("/api/submissions", (req, res) => {
    res.json(submissions);
  });

  app.post("/api/submissions", (req, res) => {
    const newSubmission = {
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date().toISOString(),
      ...req.body
    };
    submissions.push(newSubmission);
    res.status(201).json(newSubmission);
  });

  app.patch("/api/submissions/:id", (req, res) => {
    const { id } = req.params;
    const index = submissions.findIndex(s => s.id === id);
    if (index !== -1) {
      submissions[index] = { ...submissions[index], ...req.body };
      res.json(submissions[index]);
    } else {
      res.status(404).json({ error: "Submission not found" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
