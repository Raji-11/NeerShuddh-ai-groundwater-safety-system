export type RiskLevel = 'Safe' | 'At-Risk' | 'Dangerous';
export type StripColor = 'green' | 'yellow' | 'red';

export interface Location {
  lat: number;
  lng: number;
  district: string;
  state: string;
}

export interface Chemicals {
  fluoride: number;
  arsenic: number;
  nitrate: number;
  ph: number;
  tds: number;
  iron: number;
  rainfall: number;
  depth?: number;
}

export interface Analysis {
  prediction: RiskLevel;
  confidence: number;
  failedChemicals: string[];
  risks: string[];
  recommendation: string;
}

export interface Submission {
  id: string;
  type: 'volunteer' | 'asha';
  status: 'pending' | 'completed';
  timestamp: string;
  location: Location;
  imageUrl?: string;
  // Volunteer specific
  color?: StripColor;
  // ASHA specific
  chemicals?: Chemicals;
  analysis?: Analysis;
  risk?: RiskLevel;
}

export type UserRole = 'volunteer' | 'asha' | 'admin';

export interface User {
  id: string;
  role: UserRole;
  name: string;
  email: string;
}
