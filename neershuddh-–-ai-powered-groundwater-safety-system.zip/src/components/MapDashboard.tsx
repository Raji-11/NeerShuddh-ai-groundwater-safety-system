import React, { useState, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { Submission, RiskLevel } from "../types";
import { Search, Filter, Map as MapIcon, Layers, Info } from "lucide-react";
import { cn } from "../lib/utils";

// Fix Leaflet marker icons
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

const createCustomIcon = (risk: RiskLevel | string) => {
  const color = risk === 'Safe' || risk === 'green' ? '#10b981' : 
                risk === 'At-Risk' || risk === 'yellow' ? '#f59e0b' : 
                '#ef4444';
  
  return L.divIcon({
    className: 'custom-marker',
    html: `<div style="background-color: ${color}; width: 24px; height: 24px; border-radius: 50%; border: 3px solid white; box-shadow: 0 2px 4px rgba(0,0,0,0.3);"></div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });
};

const MapDashboard = ({ submissions }: { submissions: Submission[] }) => {
  const [filter, setFilter] = useState<string>("all");
  const [search, setSearch] = useState("");

  const filteredSubmissions = submissions.filter(s => {
    const matchesFilter = filter === "all" || 
      (filter === "safe" && (s.risk === "Safe" || s.color === "green")) ||
      (filter === "risk" && (s.risk === "At-Risk" || s.color === "yellow")) ||
      (filter === "danger" && (s.risk === "Dangerous" || s.color === "red"));
    
    const matchesSearch = s.location.district.toLowerCase().includes(search.toLowerCase()) ||
                         s.location.state.toLowerCase().includes(search.toLowerCase());
    
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="h-[calc(100vh-12rem)] flex flex-col space-y-4">
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-white p-4 rounded-3xl border border-slate-100 shadow-sm">
        <div className="flex items-center space-x-4 w-full md:w-auto">
          <div className="relative flex-1 md:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
            <input 
              type="text" 
              placeholder="Search district or state..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-2 focus:ring-blue-500 transition-all"
            />
          </div>
          <div className="flex items-center space-x-2 bg-slate-50 p-1 rounded-xl border border-slate-200">
            {[
              { id: "all", label: "All" },
              { id: "safe", label: "Safe", color: "bg-emerald-500" },
              { id: "risk", label: "At-Risk", color: "bg-amber-500" },
              { id: "danger", label: "Danger", color: "bg-red-500" },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setFilter(f.id)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center space-x-2",
                  filter === f.id ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                {f.color && <div className={cn("w-2 h-2 rounded-full", f.color)}></div>}
                <span>{f.label}</span>
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center space-x-2 text-xs font-bold text-slate-400 uppercase tracking-widest">
          <MapIcon className="w-4 h-4" />
          <span>{filteredSubmissions.length} Data Points</span>
        </div>
      </div>

      <div className="flex-1 rounded-3xl overflow-hidden border border-slate-200 shadow-inner relative">
        <MapContainer 
          center={[20.5937, 78.9629]} 
          zoom={5} 
          style={{ height: "100%", width: "100%" }}
          scrollWheelZoom={true}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {filteredSubmissions.map((s) => (
            <Marker 
              key={s.id} 
              position={[s.location.lat, s.location.lng]}
              icon={createCustomIcon(s.risk || s.color || 'yellow')}
            >
              <Popup className="custom-popup">
                <div className="p-2 space-y-2 min-w-[200px]">
                  <div className="flex justify-between items-start">
                    <h4 className="font-bold text-slate-900">{s.location.district}</h4>
                    <span className={cn(
                      "text-[10px] font-black uppercase px-2 py-0.5 rounded",
                      (s.risk === 'Safe' || s.color === 'green') ? "bg-emerald-100 text-emerald-700" :
                      (s.risk === 'At-Risk' || s.color === 'yellow') ? "bg-amber-100 text-amber-700" :
                      "bg-red-100 text-red-700"
                    )}>
                      {s.risk || s.color}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">{s.location.state}</p>
                  <div className="border-t border-slate-100 pt-2">
                    <div className="text-[10px] font-bold text-slate-400 uppercase mb-1">Latest Report</div>
                    <div className="text-xs font-medium">
                      {s.type === 'asha' ? "Verified Chemical Analysis" : "Volunteer Strip Test"}
                    </div>
                  </div>
                  <button 
                    onClick={() => window.location.href = `/analysis/${s.id}`}
                    className="w-full mt-2 py-2 bg-blue-600 text-white text-xs font-bold rounded-lg hover:bg-blue-700 transition-all"
                  >
                    View Full Analysis
                  </button>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>

        {/* Legend */}
        <div className="absolute bottom-6 left-6 z-[1000] bg-white/90 backdrop-blur-md p-4 rounded-2xl border border-slate-200 shadow-xl space-y-3">
          <h5 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-2">Map Legend</h5>
          {[
            { label: "Safe Water", color: "bg-emerald-500" },
            { label: "At-Risk", color: "bg-amber-500" },
            { label: "Dangerous", color: "bg-red-500" },
          ].map((item) => (
            <div key={item.label} className="flex items-center space-x-3">
              <div className={cn("w-3 h-3 rounded-full", item.color)}></div>
              <span className="text-xs font-bold text-slate-700">{item.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MapDashboard;
