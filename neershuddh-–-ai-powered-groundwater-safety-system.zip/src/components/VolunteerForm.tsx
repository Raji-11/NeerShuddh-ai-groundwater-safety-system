import React, { useState, useRef } from "react";
import { Camera, Upload, MapPin, Send, Loader2, CheckCircle2 } from "lucide-react";
import { motion } from "motion/react";
import { User, Location, StripColor } from "../types";
import { analyzeStripImage } from "../services/geminiService";
import axios from "axios";
import { cn } from "../lib/utils";

const VolunteerForm = ({ user, onSubmitted }: { user: User | null, onSubmitted: () => void }) => {
  const [image, setImage] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [detectedColor, setDetectedColor] = useState<StripColor | null>(null);
  const [location, setLocation] = useState<Location | null>(null);
  const [isLocating, setIsLocating] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      setImage(base64);
      setIsAnalyzing(true);
      const color = await analyzeStripImage(base64);
      setDetectedColor(color);
      setIsAnalyzing(false);
    };
    reader.readAsDataURL(file);
  };

  const captureLocation = () => {
    setIsLocating(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        // In a real app, we'd reverse geocode this. For demo, we'll use mock data.
        setLocation({
          lat: position.coords.latitude,
          lng: position.coords.longitude,
          district: "Sample District",
          state: "Sample State"
        });
        setIsLocating(false);
      }, (err) => {
        console.error(err);
        setIsLocating(false);
      });
    }
  };

  const handleSubmit = async () => {
    if (!image || !detectedColor || !location) return;

    setIsSubmitting(true);
    try {
      await axios.post("/api/submissions", {
        type: "volunteer",
        status: "pending",
        color: detectedColor,
        location,
        imageUrl: image,
      });
      setIsSuccess(true);
      onSubmitted();
    } catch (err) {
      console.error(err);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!user || user.role === "asha") {
    return (
      <div className="max-w-2xl mx-auto text-center py-20">
        <h2 className="text-2xl font-bold mb-4">Volunteer Access Required</h2>
        <p className="text-slate-500 mb-8">Please login as a Volunteer to submit strip tests.</p>
      </div>
    );
  }

  if (isSuccess) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md mx-auto text-center py-20 bg-white rounded-3xl shadow-xl border border-slate-100 p-8"
      >
        <div className="w-20 h-20 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="text-emerald-600 w-10 h-10" />
        </div>
        <h2 className="text-2xl font-bold mb-2">Submission Successful!</h2>
        <p className="text-slate-500 mb-8">Thank you for being a Water Guardian. ASHA workers have been notified of your report.</p>
        <button 
          onClick={() => {
            setIsSuccess(false);
            setImage(null);
            setDetectedColor(null);
            setLocation(null);
          }}
          className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold"
        >
          Submit Another Test
        </button>
      </motion.div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-12 text-center">
        <h2 className="text-4xl font-bold mb-4">Water Guardian Portal</h2>
        <p className="text-slate-500">Upload a strip test image and capture location to report water quality.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Step 1: Image Upload */}
        <div className="space-y-6">
          <div className="flex items-center space-x-3 mb-2">
            <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">1</div>
            <h3 className="text-xl font-bold">Upload Strip Test</h3>
          </div>
          
          <div 
            onClick={() => fileInputRef.current?.click()}
            className={cn(
              "aspect-square rounded-3xl border-2 border-dashed flex flex-col items-center justify-center cursor-pointer transition-all overflow-hidden relative",
              image ? "border-blue-600 bg-blue-50" : "border-slate-200 hover:border-blue-400 hover:bg-slate-50"
            )}
          >
            {image ? (
              <>
                <img src={image} alt="Strip Test" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                  <Camera className="text-white w-12 h-12" />
                </div>
              </>
            ) : (
              <>
                <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center mb-4">
                  <Upload className="text-slate-400 w-8 h-8" />
                </div>
                <p className="text-sm font-bold text-slate-500">Click to upload or take photo</p>
                <p className="text-xs text-slate-400 mt-1">Ensure good lighting for AI detection</p>
              </>
            )}
            <input 
              type="file" 
              ref={fileInputRef} 
              onChange={handleImageUpload} 
              className="hidden" 
              accept="image/*" 
              capture="environment"
            />
          </div>

          {isAnalyzing && (
            <div className="flex items-center justify-center space-x-2 text-blue-600 font-bold py-2">
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>AI Analyzing Strip Color...</span>
            </div>
          )}

          {detectedColor && !isAnalyzing && (
            <div className={cn(
              "p-4 rounded-2xl border flex items-center justify-between",
              detectedColor === 'green' ? "bg-emerald-50 border-emerald-200 text-emerald-700" :
              detectedColor === 'yellow' ? "bg-amber-50 border-amber-200 text-amber-700" :
              "bg-red-50 border-red-200 text-red-700"
            )}>
              <div className="flex items-center space-x-3">
                <div className={cn(
                  "w-4 h-4 rounded-full",
                  detectedColor === 'green' ? "bg-emerald-500" :
                  detectedColor === 'yellow' ? "bg-amber-500" :
                  "bg-red-500"
                )}></div>
                <span className="font-bold uppercase tracking-wider">AI Detected: {detectedColor}</span>
              </div>
              <CheckCircle2 className="w-5 h-5" />
            </div>
          )}
        </div>

        {/* Step 2: Location & Submit */}
        <div className="space-y-6">
          <div className="flex items-center space-x-3 mb-2">
            <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">2</div>
            <h3 className="text-xl font-bold">Capture Location</h3>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
            <button 
              onClick={captureLocation}
              disabled={isLocating}
              className="w-full py-4 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-2xl flex items-center justify-center space-x-3 transition-all"
            >
              {isLocating ? <Loader2 className="w-5 h-5 animate-spin" /> : <MapPin className="text-blue-600 w-5 h-5" />}
              <span className="font-bold text-slate-700">
                {location ? "Location Captured" : "Get Current Location"}
              </span>
            </button>

            {location && (
              <div className="space-y-3 p-4 bg-blue-50 rounded-2xl border border-blue-100">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Latitude:</span>
                  <span className="font-mono font-bold">{location.lat.toFixed(4)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">Longitude:</span>
                  <span className="font-mono font-bold">{location.lng.toFixed(4)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-500">District:</span>
                  <span className="font-bold">{location.district}</span>
                </div>
              </div>
            )}

            <div className="pt-4">
              <button 
                onClick={handleSubmit}
                disabled={!image || !location || !detectedColor || isSubmitting}
                className="w-full py-5 bg-blue-600 text-white rounded-2xl font-extrabold text-lg shadow-xl shadow-blue-200 hover:bg-blue-700 disabled:opacity-50 disabled:shadow-none transition-all flex items-center justify-center space-x-3"
              >
                {isSubmitting ? <Loader2 className="w-6 h-6 animate-spin" /> : <Send className="w-6 h-6" />}
                <span>Submit to ASHA Portal</span>
              </button>
              <p className="text-center text-xs text-slate-400 mt-4">
                By submitting, you confirm the data is accurate to your best knowledge.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default VolunteerForm;
