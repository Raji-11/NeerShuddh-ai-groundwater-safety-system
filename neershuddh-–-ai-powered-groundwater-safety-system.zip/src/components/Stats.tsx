import React from "react";
import { Users, MapPin, FlaskConical, IndianRupee } from "lucide-react";
import { motion } from "motion/react";

const Stats = () => {
  const stats = [
    { label: "People at Risk", value: "600M", icon: <Users className="text-blue-600" />, color: "bg-blue-50" },
    { label: "Districts Affected", value: "230", icon: <MapPin className="text-cyan-600" />, color: "bg-cyan-50" },
    { label: "Chemicals Detected", value: "8", icon: <FlaskConical className="text-indigo-600" />, color: "bg-indigo-50" },
    { label: "Cost per Village", value: "₹0", icon: <IndianRupee className="text-emerald-600" />, color: "bg-emerald-50" },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
      {stats.map((stat, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: i * 0.1 }}
          className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow text-center"
        >
          <div className={`w-12 h-12 ${stat.color} rounded-2xl flex items-center justify-center mx-auto mb-4`}>
            {stat.icon}
          </div>
          <div className="text-3xl font-black text-slate-900 mb-1">{stat.value}</div>
          <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">{stat.label}</div>
        </motion.div>
      ))}
    </div>
  );
};

export default Stats;
