import React from "react";
import { Submission } from "../types";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, Cell } from "recharts";
import { TrendingUp, MapPin, AlertCircle, Database, Calendar } from "lucide-react";
import { cn } from "../lib/utils";

const AdminPanel = ({ submissions }: { submissions: Submission[] }) => {
  // Mock trend data
  const trendData = [
    { month: "Jan", contamination: 45, rainfall: 20 },
    { month: "Feb", contamination: 52, rainfall: 15 },
    { month: "Mar", contamination: 48, rainfall: 10 },
    { month: "Apr", contamination: 65, rainfall: 5 },
    { month: "May", contamination: 78, rainfall: 8 },
    { month: "Jun", contamination: 85, rainfall: 120 },
    { month: "Jul", contamination: 42, rainfall: 350 },
    { month: "Aug", contamination: 38, rainfall: 310 },
  ];

  const districtData = [
    { name: "New Delhi", count: 45, risk: "High" },
    { name: "Lucknow", count: 32, risk: "Medium" },
    { name: "Patna", count: 58, risk: "Critical" },
    { name: "Jaipur", count: 28, risk: "Low" },
    { name: "Kanpur", count: 41, risk: "High" },
  ];

  const stats = [
    { label: "Total Reports", value: submissions.length, icon: <Database className="text-blue-600" /> },
    { label: "Active Districts", value: "12", icon: <MapPin className="text-cyan-600" /> },
    { label: "Critical Alerts", value: submissions.filter(s => s.risk === "Dangerous").length, icon: <AlertCircle className="text-red-600" /> },
    { label: "Last Updated", value: "Today", icon: <Calendar className="text-emerald-600" /> },
  ];

  return (
    <div className="space-y-8 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold">Admin Dashboard</h2>
          <p className="text-slate-500">National groundwater contamination monitoring & analytics.</p>
        </div>
        <button className="px-6 py-3 bg-blue-600 text-white rounded-2xl font-bold shadow-lg shadow-blue-200 hover:bg-blue-700 transition-all">
          Export National Report
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center">
                {stat.icon}
              </div>
              <TrendingUp className="text-emerald-500 w-4 h-4" />
            </div>
            <div className="text-2xl font-black text-slate-900">{stat.value}</div>
            <div className="text-xs font-bold text-slate-400 uppercase tracking-widest">{stat.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Trend Chart */}
        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold">Contamination vs Rainfall</h3>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-600 rounded-full"></div>
                <span className="text-xs font-bold text-slate-500">Contamination</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-cyan-400 rounded-full"></div>
                <span className="text-xs font-bold text-slate-500">Rainfall</span>
              </div>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#94a3b8' }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Line type="monotone" dataKey="contamination" stroke="#2563eb" strokeWidth={4} dot={{ r: 4, fill: '#2563eb', strokeWidth: 2, stroke: '#fff' }} activeDot={{ r: 8 }} />
                <Line type="monotone" dataKey="rainfall" stroke="#22d3ee" strokeWidth={4} dot={{ r: 4, fill: '#22d3ee', strokeWidth: 2, stroke: '#fff' }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* District Breakdown */}
        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
          <h3 className="text-xl font-bold mb-8">District-wise Risk Analysis</h3>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={districtData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b', fontWeight: 600 }} width={100} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="count" radius={[0, 8, 8, 0]} barSize={32}>
                  {districtData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.risk === 'Critical' ? '#ef4444' : entry.risk === 'High' ? '#f97316' : '#3b82f6'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recent Activity Table */}
      <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-8 border-b border-slate-50">
          <h3 className="text-xl font-bold">Recent National Submissions</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50">
                <th className="px-8 py-4 text-xs font-black uppercase tracking-widest text-slate-400">Location</th>
                <th className="px-8 py-4 text-xs font-black uppercase tracking-widest text-slate-400">Type</th>
                <th className="px-8 py-4 text-xs font-black uppercase tracking-widest text-slate-400">Risk Level</th>
                <th className="px-8 py-4 text-xs font-black uppercase tracking-widest text-slate-400">Timestamp</th>
                <th className="px-8 py-4 text-xs font-black uppercase tracking-widest text-slate-400">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {submissions.map((s) => (
                <tr key={s.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-8 py-4">
                    <div className="font-bold text-slate-900">{s.location.district}</div>
                    <div className="text-xs text-slate-500">{s.location.state}</div>
                  </td>
                  <td className="px-8 py-4">
                    <span className={cn(
                      "px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider",
                      s.type === 'asha' ? "bg-blue-100 text-blue-700" : "bg-purple-100 text-purple-700"
                    )}>
                      {s.type}
                    </span>
                  </td>
                  <td className="px-8 py-4">
                    <div className="flex items-center space-x-2">
                      <div className={cn(
                        "w-2 h-2 rounded-full",
                        (s.risk === 'Safe' || s.color === 'green') ? "bg-emerald-500" :
                        (s.risk === 'At-Risk' || s.color === 'yellow') ? "bg-amber-500" :
                        "bg-red-500"
                      )}></div>
                      <span className="text-sm font-bold text-slate-700">{s.risk || s.color}</span>
                    </div>
                  </td>
                  <td className="px-8 py-4 text-sm text-slate-500">
                    {new Date(s.timestamp).toLocaleString()}
                  </td>
                  <td className="px-8 py-4">
                    <button 
                      onClick={() => window.location.href = `/analysis/${s.id}`}
                      className="text-blue-600 font-bold text-sm hover:underline"
                    >
                      View Details
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
