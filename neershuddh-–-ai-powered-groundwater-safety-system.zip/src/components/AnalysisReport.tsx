import React, { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { Submission, RiskLevel } from "../types";
import { ShieldCheck, AlertTriangle, ShieldAlert, ArrowLeft, Download, Share2, Info, Activity, Zap, MessageSquare, CheckCircle2, Loader2 } from "lucide-react";
import { motion } from "motion/react";
import { cn } from "../lib/utils";

const ConfidenceGauge = ({ score }: { score: number }) => {
  const radius = 36;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score * circumference);

  return (
    <div className="relative flex items-center justify-center w-24 h-24">
      <svg className="w-full h-full -rotate-90">
        <circle
          cx="48"
          cy="48"
          r={radius}
          stroke="currentColor"
          strokeWidth="8"
          fill="transparent"
          className="text-slate-100"
        />
        <motion.circle
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, ease: "easeOut" }}
          cx="48"
          cy="48"
          r={radius}
          stroke="currentColor"
          strokeWidth="8"
          fill="transparent"
          strokeDasharray={circumference}
          className="text-blue-600"
        />
      </svg>
      <div className="absolute text-lg font-black text-slate-900">
        {(score * 100).toFixed(0)}%
      </div>
    </div>
  );
};

const AnalysisReport = ({ submissions }: { submissions: Submission[] }) => {
  const { id } = useParams();
  const [isResending, setIsResending] = useState(false);
  const [smsSent, setSmsSent] = useState(true);
  
  const submission = submissions.find(s => s.id === id);

  if (!submission) {
    return (
      <div className="text-center py-20">
        <h2 className="text-2xl font-bold">Report Not Found</h2>
        <Link to="/map" className="text-blue-600 font-bold mt-4 inline-block">Back to Map</Link>
      </div>
    );
  }

  const isDangerous = submission.risk === "Dangerous";
  const isAtRisk = submission.risk === "At-Risk";
  const isSafe = submission.risk === "Safe";
  const confidence = submission.analysis?.confidence || 0;

  const handleResendSms = () => {
    setIsResending(true);
    setTimeout(() => {
      setIsResending(false);
      setSmsSent(true);
    }, 1500);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <Link to="/map" className="flex items-center space-x-2 text-slate-500 hover:text-blue-600 font-bold transition-colors">
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </Link>
        <div className="flex space-x-3">
          <button className="p-3 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-all">
            <Share2 className="w-5 h-5 text-slate-600" />
          </button>
          <button className="p-3 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 transition-all">
            <Download className="w-5 h-5 text-slate-600" />
          </button>
        </div>
      </div>

      {/* Hero Status */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className={cn(
          "p-8 md:p-12 rounded-[2.5rem] border-4 flex flex-col md:flex-row items-center gap-8 relative overflow-hidden",
          isSafe ? "bg-emerald-50 border-emerald-100" :
          isAtRisk ? "bg-amber-50 border-amber-100" :
          "bg-red-50 border-red-100"
        )}
      >
        {/* Background Pattern */}
        <div className="absolute top-0 right-0 opacity-10">
          <Activity className="w-64 h-64 -translate-y-1/4 translate-x-1/4" />
        </div>

        <div className={cn(
          "w-32 h-32 rounded-full flex items-center justify-center shrink-0 shadow-2xl",
          isSafe ? "bg-emerald-500 shadow-emerald-200" :
          isAtRisk ? "bg-amber-500 shadow-amber-200" :
          "bg-red-500 shadow-red-200"
        )}>
          {isSafe ? <ShieldCheck className="text-white w-16 h-16" /> :
           isAtRisk ? <AlertTriangle className="text-white w-16 h-16" /> :
           <ShieldAlert className="text-white w-16 h-16" />}
        </div>

        <div className="text-center md:text-left space-y-4 relative z-10 flex-1">
          <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
            <span className={cn(
              "px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest",
              isSafe ? "bg-emerald-200 text-emerald-800" :
              isAtRisk ? "bg-amber-200 text-amber-800" :
              "bg-red-200 text-red-800"
            )}>
              {submission.risk} Level Detected
            </span>
            <span className="px-4 py-1.5 bg-white/50 rounded-full text-xs font-bold text-slate-600 flex items-center space-x-2">
              <Activity className="w-3 h-3" />
              <span>AI Analysis Confidence</span>
            </span>
          </div>
          <h1 className="text-4xl md:text-6xl font-black text-slate-900 leading-tight">
            {submission.analysis?.recommendation || "Analysis Pending"}
          </h1>
          <p className="text-lg text-slate-600 max-w-xl">
            Location: <span className="font-bold text-slate-900">{submission.location.district}, {submission.location.state}</span>
            <br />
            Reported on {new Date(submission.timestamp).toLocaleString()}
          </p>
        </div>

        <div className="shrink-0 bg-white/40 backdrop-blur-sm p-6 rounded-3xl border border-white/50 flex flex-col items-center space-y-2">
          <ConfidenceGauge score={confidence} />
          <span className="text-[10px] font-black uppercase tracking-widest text-slate-500">ML Confidence</span>
        </div>
      </motion.div>

      {isDangerous && (
        <motion.div 
          initial={{ scale: 0.95, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="bg-red-600 text-white p-8 rounded-[2rem] shadow-xl shadow-red-200 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <MessageSquare className="w-32 h-32" />
          </div>
          
          <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
            <div className="flex items-center space-x-6">
              <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center animate-pulse shrink-0">
                <Zap className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <h4 className="text-2xl font-black uppercase tracking-wider">Critical SMS Alert Dispatched</h4>
                <p className="text-red-100 font-medium">Emergency notifications sent to 12 local ASHA workers and the District Health Officer via Twilio.</p>
                <div className="flex items-center space-x-3 pt-2">
                  <div className="flex items-center space-x-1 px-2 py-1 bg-white/20 rounded-lg text-[10px] font-bold">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>Status: Delivered</span>
                  </div>
                  <div className="text-[10px] font-bold opacity-60">Sent: {new Date().toLocaleTimeString()}</div>
                </div>
              </div>
            </div>
            
            <button 
              onClick={handleResendSms}
              disabled={isResending}
              className="px-6 py-3 bg-white text-red-600 rounded-xl font-bold hover:bg-red-50 transition-all flex items-center space-x-2 shrink-0"
            >
              {isResending ? <Loader2 className="w-4 h-4 animate-spin" /> : <MessageSquare className="w-4 h-4" />}
              <span>{isResending ? "Sending..." : "Resend Alert"}</span>
            </button>
          </div>
        </motion.div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Chemical Breakdown */}
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
            <h3 className="text-2xl font-bold mb-8 flex items-center space-x-3">
              <Activity className="text-blue-600 w-6 h-6" />
              <span>Chemical Composition</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {[
                { label: "Fluoride", value: submission.chemicals?.fluoride, limit: 1.5, unit: "mg/L" },
                { label: "Arsenic", value: submission.chemicals?.arsenic, limit: 0.01, unit: "mg/L" },
                { label: "Nitrate", value: submission.chemicals?.nitrate, limit: 45, unit: "mg/L" },
                { label: "pH Level", value: submission.chemicals?.ph, limit: "6.5-8.5", unit: "" },
                { label: "TDS", value: submission.chemicals?.tds, limit: 500, unit: "mg/L" },
                { label: "Iron", value: submission.chemicals?.iron, limit: 0.3, unit: "mg/L" },
              ].map((chem) => {
                const isFailed = submission.analysis?.failedChemicals.includes(chem.label);
                return (
                  <div key={chem.label} className="space-y-2">
                    <div className="flex justify-between items-end">
                      <span className="text-sm font-bold text-slate-500 uppercase tracking-wider">{chem.label}</span>
                      <span className={cn(
                        "text-lg font-black",
                        isFailed ? "text-red-600" : "text-emerald-600"
                      )}>
                        {chem.value} <span className="text-xs font-bold opacity-60">{chem.unit}</span>
                      </span>
                    </div>
                    <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: isFailed ? "90%" : "40%" }}
                        className={cn(
                          "h-full rounded-full",
                          isFailed ? "bg-red-500" : "bg-emerald-500"
                        )}
                      />
                    </div>
                    <div className="text-[10px] font-bold text-slate-400 uppercase">Limit: {chem.limit} {chem.unit}</div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
            <h3 className="text-2xl font-bold mb-6 flex items-center space-x-3">
              <Info className="text-blue-600 w-6 h-6" />
              <span>Health Risks & Advice</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h4 className="font-bold text-slate-400 uppercase text-xs tracking-widest">Potential Risks</h4>
                <div className="flex flex-wrap gap-2">
                  {submission.analysis?.risks.map((risk) => (
                    <span key={risk} className="px-4 py-2 bg-red-50 text-red-700 rounded-xl text-sm font-bold border border-red-100">
                      {risk}
                    </span>
                  ))}
                </div>
              </div>
              <div className="space-y-4">
                <h4 className="font-bold text-slate-400 uppercase text-xs tracking-widest">Recommended Action</h4>
                <div className="p-4 bg-blue-50 border border-blue-100 rounded-2xl text-blue-800 font-bold">
                  {submission.analysis?.recommendation}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar Info */}
        <div className="space-y-8">
          <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm space-y-6">
            <h4 className="font-bold text-slate-900">Report Details</h4>
            <div className="space-y-4">
              <div className="flex justify-between items-center py-3 border-b border-slate-50">
                <span className="text-sm text-slate-500">Submission ID</span>
                <span className="text-sm font-mono font-bold text-slate-900">#{submission.id}</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-slate-50">
                <span className="text-sm text-slate-500">Method</span>
                <span className="text-sm font-bold text-slate-900">{submission.type === 'asha' ? "Lab Verified" : "Strip Test"}</span>
              </div>
              <div className="flex justify-between items-center py-3 border-b border-slate-50">
                <span className="text-sm text-slate-500">Rainfall</span>
                <span className="text-sm font-bold text-slate-900">{submission.chemicals?.rainfall} mm</span>
              </div>
              <div className="flex justify-between items-center py-3">
                <span className="text-sm text-slate-500">Water Depth</span>
                <span className="text-sm font-bold text-slate-900">{submission.chemicals?.depth} m</span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-cyan-500 p-8 rounded-[2.5rem] text-white shadow-xl shadow-blue-200">
            <h4 className="text-xl font-black mb-4">Need Help?</h4>
            <p className="text-blue-100 text-sm mb-6">If you suspect water contamination in your area, contact your local ASHA worker immediately.</p>
            <button className="w-full py-4 bg-white text-blue-600 rounded-2xl font-bold hover:bg-blue-50 transition-all">
              Contact Local Authority
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalysisReport;
