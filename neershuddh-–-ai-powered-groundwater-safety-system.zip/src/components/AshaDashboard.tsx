import React, { useState } from "react";
import { AlertTriangle, CheckCircle, Clock, ChevronRight, FlaskConical, Send, Loader2, Info } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { User, Submission, Chemicals } from "../types";
import { predictWaterSafety } from "../services/geminiService";
import axios from "axios";
import { cn } from "../lib/utils";
import { useNavigate } from "react-router-dom";

const AshaDashboard = ({ user, submissions, onUpdated }: { user: User | null, submissions: Submission[], onUpdated: () => void }) => {
  const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);
  const [chemicals, setChemicals] = useState<Chemicals>({
    fluoride: 0,
    arsenic: 0,
    nitrate: 0,
    ph: 7,
    tds: 500,
    iron: 0,
    rainfall: 500,
    depth: 30
  });
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const navigate = useNavigate();

  const pendingSubmissions = submissions.filter(s => s.status === "pending");
  const completedSubmissions = submissions.filter(s => s.status === "completed");

  const handleChemicalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setChemicals(prev => ({ ...prev, [name]: parseFloat(value) || 0 }));
  };

  const handleAnalyze = async () => {
    if (!selectedSubmission) return;
    setIsAnalyzing(true);
    try {
      const analysis = await predictWaterSafety(chemicals);
      await axios.patch(`/api/submissions/${selectedSubmission.id}`, {
        status: "completed",
        chemicals,
        analysis,
        risk: analysis.prediction,
        type: "asha"
      });
      onUpdated();
      navigate(`/analysis/${selectedSubmission.id}`);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAnalyzing(false);
    }
  };

  if (!user || (user.role !== "asha" && user.role !== "admin")) {
    return (
      <div className="max-w-2xl mx-auto text-center py-20">
        <h2 className="text-2xl font-bold mb-4">ASHA Access Required</h2>
        <p className="text-slate-500 mb-8">Please login as an ASHA Worker to access this portal.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold">ASHA Portal</h2>
          <p className="text-slate-500">Manage alerts and verify water quality reports.</p>
        </div>
        <div className="flex space-x-4">
          <div className="px-6 py-3 bg-amber-50 rounded-2xl border border-amber-100 flex items-center space-x-2">
            <Clock className="text-amber-600 w-5 h-5" />
            <span className="font-bold text-amber-900">{pendingSubmissions.length} Pending Alerts</span>
          </div>
          <div className="px-6 py-3 bg-emerald-50 rounded-2xl border border-emerald-100 flex items-center space-x-2">
            <CheckCircle className="text-emerald-600 w-5 h-5" />
            <span className="font-bold text-emerald-900">{completedSubmissions.length} Verified</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Alerts List */}
        <div className="lg:col-span-1 space-y-4">
          <h3 className="text-xl font-bold flex items-center space-x-2">
            <AlertTriangle className="text-amber-500 w-5 h-5" />
            <span>Pending Reports</span>
          </h3>
          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
            {pendingSubmissions.length === 0 ? (
              <div className="p-8 bg-white rounded-3xl border border-slate-100 text-center">
                <p className="text-slate-400 font-medium">No pending alerts</p>
              </div>
            ) : (
              pendingSubmissions.map((s) => (
                <button
                  key={s.id}
                  onClick={() => setSelectedSubmission(s)}
                  className={cn(
                    "w-full p-4 text-left rounded-2xl border transition-all group",
                    selectedSubmission?.id === s.id 
                      ? "bg-blue-600 border-blue-600 text-white shadow-lg shadow-blue-200" 
                      : "bg-white border-slate-100 hover:border-blue-200 hover:bg-blue-50"
                  )}
                >
                  <div className="flex justify-between items-start mb-2">
                    <span className={cn(
                      "text-[10px] font-black uppercase tracking-widest px-2 py-1 rounded-md",
                      selectedSubmission?.id === s.id ? "bg-white/20" : "bg-slate-100 text-slate-500"
                    )}>
                      {s.location.district}
                    </span>
                    <span className="text-[10px] opacity-60">{new Date(s.timestamp).toLocaleDateString()}</span>
                  </div>
                  <div className="font-bold mb-1">Strip Color: {s.color}</div>
                  <div className="flex items-center text-xs opacity-80">
                    <MapPin className="w-3 h-3 mr-1" />
                    {s.location.lat.toFixed(2)}, {s.location.lng.toFixed(2)}
                  </div>
                </button>
              ))
            )}
          </div>
        </div>

        {/* Verification Form */}
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            {selectedSubmission ? (
              <motion.div
                key={selectedSubmission.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden"
              >
                <div className="p-8 border-b border-slate-100 bg-slate-50/50">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-2xl font-bold">Verify Water Quality</h3>
                    <button onClick={() => setSelectedSubmission(null)} className="text-slate-400 hover:text-slate-600">
                      <X className="w-6 h-6" />
                    </button>
                  </div>
                  <div className="flex items-center space-x-4">
                    <img src={selectedSubmission.imageUrl} className="w-20 h-20 rounded-xl object-cover border border-white shadow-sm" />
                    <div>
                      <div className="text-sm font-bold text-slate-500 uppercase tracking-wider">Reported by Volunteer</div>
                      <div className="flex items-center space-x-2">
                        <div className={cn("w-3 h-3 rounded-full", selectedSubmission.color === 'red' ? "bg-red-500" : "bg-amber-500")}></div>
                        <span className="font-bold text-lg capitalize">{selectedSubmission.color} Strip Alert</span>
                      </div>
                      <div className="text-xs text-slate-400">{selectedSubmission.location.district}, {selectedSubmission.location.state}</div>
                    </div>
                  </div>
                </div>

                <div className="p-8 space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {[
                      { label: "Fluoride (mg/L)", name: "fluoride", icon: <FlaskConical className="w-4 h-4" /> },
                      { label: "Arsenic (mg/L)", name: "arsenic", icon: <FlaskConical className="w-4 h-4" /> },
                      { label: "Nitrate (mg/L)", name: "nitrate", icon: <FlaskConical className="w-4 h-4" /> },
                      { label: "pH Level", name: "ph", icon: <FlaskConical className="w-4 h-4" /> },
                      { label: "TDS (mg/L)", name: "tds", icon: <FlaskConical className="w-4 h-4" /> },
                      { label: "Iron (mg/L)", name: "iron", icon: <FlaskConical className="w-4 h-4" /> },
                      { label: "Rainfall (mm)", name: "rainfall", icon: <FlaskConical className="w-4 h-4" /> },
                      { label: "Depth (m)", name: "depth", icon: <FlaskConical className="w-4 h-4" /> },
                    ].map((field) => (
                      <div key={field.name} className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center space-x-2">
                          {field.icon}
                          <span>{field.label}</span>
                        </label>
                        <input
                          type="number"
                          name={field.name}
                          value={(chemicals as any)[field.name]}
                          onChange={handleChemicalChange}
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                          placeholder="0.00"
                        />
                      </div>
                    ))}
                  </div>

                  <div className="pt-4">
                    <button
                      onClick={handleAnalyze}
                      disabled={isAnalyzing}
                      className="w-full py-5 bg-blue-600 text-white rounded-2xl font-extrabold text-lg shadow-xl shadow-blue-200 hover:bg-blue-700 transition-all flex items-center justify-center space-x-3"
                    >
                      {isAnalyzing ? <Loader2 className="w-6 h-6 animate-spin" /> : <Send className="w-6 h-6" />}
                      <span>Run AI Analysis & Verify</span>
                    </button>
                    <div className="flex items-center justify-center space-x-2 mt-4 text-slate-400">
                      <Info className="w-4 h-4" />
                      <span className="text-xs">AI will predict health risks and safety levels based on these values.</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            ) : (
              <div className="h-full min-h-[400px] flex flex-col items-center justify-center bg-white rounded-3xl border border-dashed border-slate-200 p-12 text-center">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                  <FlaskConical className="text-slate-300 w-10 h-10" />
                </div>
                <h3 className="text-xl font-bold text-slate-400 mb-2">Select a Report to Verify</h3>
                <p className="text-slate-400 max-w-xs">Choose a pending strip test from the left to enter chemical data and run analysis.</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

const MapPin = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
    <circle cx="12" cy="10" r="3"></circle>
  </svg>
);

const X = ({ className }: { className?: string }) => (
  <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="6" x2="6" y2="18"></line>
    <line x1="6" y1="6" x2="18" y2="18"></line>
  </svg>
);

export default AshaDashboard;
