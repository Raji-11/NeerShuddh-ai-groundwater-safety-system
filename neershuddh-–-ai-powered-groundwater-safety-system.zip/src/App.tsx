import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link, useNavigate, useLocation } from "react-router-dom";
import { Droplets, Shield, Map as MapIcon, User, LogIn, Menu, X, AlertTriangle, CheckCircle, Info } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "./lib/utils";
import { UserRole, User as UserType, Submission } from "./types";
import axios from "axios";

// Components
import Hero from "./components/Hero";
import Stats from "./components/Stats";
import VolunteerForm from "./components/VolunteerForm";
import AshaDashboard from "./components/AshaDashboard";
import MapDashboard from "./components/MapDashboard";
import AnalysisReport from "./components/AnalysisReport";
import AdminPanel from "./components/AdminPanel";

const Layout = ({ children, user, onLogout }: { children: React.ReactNode, user: UserType | null, onLogout: () => void }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navItems = [
    { name: "Home", path: "/", roles: ["all"] },
    { name: "Live Map", path: "/map", roles: ["all"] },
    { name: "Volunteer", path: "/volunteer", roles: ["volunteer", "admin"] },
    { name: "ASHA Portal", path: "/asha", roles: ["asha", "admin"] },
    { name: "Admin", path: "/admin", roles: ["admin"] },
  ];

  const filteredNav = navItems.filter(item => 
    item.roles.includes("all") || (user && (item.roles.includes(user.role) || user.role === "admin"))
  );

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans">
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <Link to="/" className="flex items-center space-x-2 group">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <Droplets className="text-white w-6 h-6" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-cyan-500 bg-clip-text text-transparent">
                NeerShuddh
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center space-x-8">
              {filteredNav.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={cn(
                    "text-sm font-medium transition-colors hover:text-blue-600",
                    location.pathname === item.path ? "text-blue-600" : "text-slate-600"
                  )}
                >
                  {item.name}
                </Link>
              ))}
              {user ? (
                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2 px-3 py-1 bg-slate-100 rounded-full">
                    <User className="w-4 h-4 text-slate-500" />
                    <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">{user.role}</span>
                  </div>
                  <button 
                    onClick={onLogout}
                    className="text-sm font-medium text-slate-600 hover:text-red-600 transition-colors"
                  >
                    Logout
                  </button>
                </div>
              ) : (
                <Link
                  to="/login"
                  className="bg-blue-600 text-white px-5 py-2 rounded-xl text-sm font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-200"
                >
                  Login
                </Link>
              )}
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-slate-600">
                {isMenuOpen ? <X /> : <Menu />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Nav */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white border-b border-slate-200 overflow-hidden"
            >
              <div className="px-4 pt-2 pb-6 space-y-2">
                {filteredNav.map((item) => (
                  <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => setIsMenuOpen(false)}
                    className="block px-3 py-2 text-base font-medium text-slate-600 hover:text-blue-600 hover:bg-slate-50 rounded-lg"
                  >
                    {item.name}
                  </Link>
                ))}
                {!user && (
                  <Link
                    to="/login"
                    onClick={() => setIsMenuOpen(false)}
                    className="block w-full text-center bg-blue-600 text-white px-5 py-3 rounded-xl text-base font-semibold"
                  >
                    Login
                  </Link>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {children}
      </main>

      <footer className="bg-white border-t border-slate-200 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-2 mb-4">
                <Droplets className="text-blue-600 w-6 h-6" />
                <span className="text-xl font-bold">NeerShuddh</span>
              </div>
              <p className="text-slate-500 max-w-sm">
                AI-Powered Shield for India's Groundwater. Protecting millions from contamination through community-driven monitoring and AI analysis.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-slate-500 text-sm">
                <li><Link to="/map">Live Map</Link></li>
                <li><Link to="/volunteer">Become a Guardian</Link></li>
                <li><Link to="/asha">ASHA Portal</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contact</h4>
              <ul className="space-y-2 text-slate-500 text-sm">
                <li>support@neershuddh.org</li>
                <li>+91 1800-WATER-SAFE</li>
                <li>New Delhi, India</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-100 mt-12 pt-8 text-center text-slate-400 text-xs">
            © 2026 NeerShuddh. All rights reserved. Built for Social Impact.
          </div>
        </div>
      </footer>
    </div>
  );
};

const LoginPage = ({ onLogin }: { onLogin: (user: UserType) => void }) => {
  const navigate = useNavigate();
  const roles: UserRole[] = ["volunteer", "asha", "admin"];

  return (
    <div className="max-w-md mx-auto mt-20 p-8 bg-white rounded-3xl shadow-xl border border-slate-100">
      <div className="text-center mb-8">
        <div className="w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <LogIn className="text-blue-600 w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold">Welcome Back</h2>
        <p className="text-slate-500">Select your role to continue</p>
      </div>
      <div className="space-y-4">
        {roles.map((role) => (
          <button
            key={role}
            onClick={() => {
              onLogin({ id: role, role, name: role.charAt(0).toUpperCase() + role.slice(1), email: `${role}@example.com` });
              navigate(role === "volunteer" ? "/volunteer" : role === "asha" ? "/asha" : "/admin");
            }}
            className="w-full py-4 px-6 bg-slate-50 hover:bg-blue-50 border border-slate-200 hover:border-blue-200 rounded-2xl text-left transition-all group flex items-center justify-between"
          >
            <div>
              <span className="block font-bold text-slate-800 capitalize">{role}</span>
              <span className="text-xs text-slate-500">Access {role} dashboard and tools</span>
            </div>
            <div className="w-8 h-8 rounded-full bg-white border border-slate-200 flex items-center justify-center group-hover:bg-blue-600 group-hover:border-blue-600 transition-all">
              <LogIn className="w-4 h-4 text-slate-400 group-hover:text-white" />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<UserType | null>(null);
  const [submissions, setSubmissions] = useState<Submission[]>([]);

  useEffect(() => {
    fetchSubmissions();
  }, []);

  const fetchSubmissions = async () => {
    try {
      const res = await axios.get("/api/submissions");
      setSubmissions(res.data);
    } catch (err) {
      console.error("Failed to fetch submissions", err);
    }
  };

  const handleLogin = (u: UserType) => setUser(u);
  const handleLogout = () => setUser(null);

  return (
    <Router>
      <Layout user={user} onLogout={handleLogout}>
        <Routes>
          <Route path="/" element={
            <div className="space-y-20">
              <Hero />
              <Stats />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
                <div className="space-y-6">
                  <h2 className="text-4xl font-bold leading-tight">
                    Why <span className="text-blue-600">NeerShuddh</span> Matters?
                  </h2>
                  <p className="text-lg text-slate-600">
                    India faces a massive groundwater crisis. Millions consume water contaminated with arsenic, fluoride, and nitrates without knowing the risks. 
                  </p>
                  <div className="space-y-4">
                    {[
                      { icon: <AlertTriangle className="text-amber-500" />, title: "Invisible Killers", desc: "Chemicals like Arsenic are odorless and tasteless but cause cancer." },
                      { icon: <CheckCircle className="text-emerald-500" />, title: "Community Driven", desc: "Volunteers use simple strips to flag potential risks instantly." },
                      { icon: <Shield className="text-blue-500" />, title: "AI Powered", desc: "Advanced ML models predict safety trends and alert authorities." },
                    ].map((item, i) => (
                      <div key={i} className="flex space-x-4 p-4 bg-white rounded-2xl border border-slate-100 shadow-sm">
                        <div className="mt-1">{item.icon}</div>
                        <div>
                          <h4 className="font-bold">{item.title}</h4>
                          <p className="text-sm text-slate-500">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="relative">
                  <div className="absolute -inset-4 bg-blue-100/50 rounded-3xl blur-2xl -z-10"></div>
                  <img 
                    src="https://picsum.photos/seed/water-india/800/600" 
                    alt="Water Crisis" 
                    className="rounded-3xl shadow-2xl border border-white"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>
            </div>
          } />
          <Route path="/login" element={<LoginPage onLogin={handleLogin} />} />
          <Route path="/map" element={<MapDashboard submissions={submissions} />} />
          <Route path="/volunteer" element={<VolunteerForm user={user} onSubmitted={fetchSubmissions} />} />
          <Route path="/asha" element={<AshaDashboard user={user} submissions={submissions} onUpdated={fetchSubmissions} />} />
          <Route path="/admin" element={<AdminPanel submissions={submissions} />} />
          <Route path="/analysis/:id" element={<AnalysisReport submissions={submissions} />} />
        </Routes>
      </Layout>
    </Router>
  );
}
