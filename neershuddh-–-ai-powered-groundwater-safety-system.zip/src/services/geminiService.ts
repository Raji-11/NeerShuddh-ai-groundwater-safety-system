import { GoogleGenAI } from "@google/genai";
import { Chemicals, Analysis, StripColor } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const analyzeStripImage = async (base64Image: string): Promise<StripColor> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: base64Image.split(",")[1] || base64Image,
            },
          },
          {
            text: "Analyze this water quality strip test. Determine the dominant color: green (safe), yellow (at-risk), or red (dangerous). Respond with only the color name in lowercase.",
          },
        ],
      },
    });

    const color = response.text?.trim().toLowerCase() as StripColor;
    return ['green', 'yellow', 'red'].includes(color) ? color : 'yellow';
  } catch (error) {
    console.error("AI Strip Analysis Error:", error);
    return 'yellow'; // Fallback
  }
};

export const predictWaterSafety = async (chemicals: Chemicals): Promise<Analysis> => {
  try {
    const prompt = `Analyze the following groundwater chemical values for safety in India:
    Fluoride: ${chemicals.fluoride} mg/L (Limit: 1.5)
    Arsenic: ${chemicals.arsenic} mg/L (Limit: 0.01)
    Nitrate: ${chemicals.nitrate} mg/L (Limit: 45)
    pH: ${chemicals.ph} (Limit: 6.5-8.5)
    TDS: ${chemicals.tds} mg/L (Limit: 500-2000)
    Iron: ${chemicals.iron} mg/L (Limit: 0.3)
    Rainfall: ${chemicals.rainfall} mm
    Depth: ${chemicals.depth || 'N/A'} m

    Provide a JSON response with:
    - prediction: "Safe", "At-Risk", or "Dangerous"
    - confidence: 0.0 to 1.0
    - failedChemicals: array of strings
    - risks: array of potential health risks
    - recommendation: short action advice`;

    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    return JSON.parse(response.text || "{}");
  } catch (error) {
    console.error("AI Safety Prediction Error:", error);
    return {
      prediction: "At-Risk",
      confidence: 0.5,
      failedChemicals: ["Unknown"],
      risks: ["General contamination"],
      recommendation: "Boil water before use"
    };
  }
};
